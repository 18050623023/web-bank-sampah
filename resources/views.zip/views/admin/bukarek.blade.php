@extends('layouts.master')

@section('title','Kategori')

@section('conten')
    
		<div class="row">
					<div class="col-xl-9 mx-auto">
						<div class="card border-top border-0 border-4 border-info">
							<div class="card-body">
								<div class="border p-4 rounded">
									<div class="card-title d-flex align-items-center">
										<h5 class="mb-0 text-info">Silahkan Buka Tabungan Dulu</h5>
									</div>
								</div>
							</div>
						</div>
					</div>
		</div>

@endsection
